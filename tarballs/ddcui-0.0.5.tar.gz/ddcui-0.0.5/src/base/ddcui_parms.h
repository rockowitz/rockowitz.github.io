// ddcui_parms.h

// Copyright (C) 2018-2019 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef DDCUI_PARMS_H_
#define DDCUI_PARMS_H_

#define DDCUI_VERSION "0.0.5"

#endif /* DDCUI_PARMS_H_ */
