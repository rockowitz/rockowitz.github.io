/** @file user_interface_options_state.cpp
 * Maintains the current state of the User Interface Options dialog
 */

// Copyright (C) 2018-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

// NB was originally named ui_options_state.h etc, but the ui prefix is
// special, causes the user interface compiler to look for a dialog named ui_options_state_dialog

#include "cmdline/ddcui_parsed_cmd.h"
#include "ddcui_core.h"
#include "c_util/debug_util.h"
#include "ddcui_rtti.h"

#include "user_interface_options_state.h"

 UserInterfaceOptionsState::UserInterfaceOptionsState()
     : _cls(metaObject()->className())
 {
 }

 UserInterfaceOptionsState::UserInterfaceOptionsState(Parsed_Ddcui_Cmd* parsed_cmd)
     : _cls(metaObject()->className())
 {
    bool debug = false;
    TRACEMCF_STARTING(debug, "");
    _controlKeyRequired = parsed_cmd->flags & CMD_FLAG_UI_REQUIRE_CONTROL_KEY;
    TRACEMCF_DONE(debug, "");
 }

 UserInterfaceOptionsState::UserInterfaceOptionsState(UserInterfaceOptionsState &other)
     : QObject()
     , _cls(metaObject()->className())
 {
    _controlKeyRequired = other._controlKeyRequired;
 }

 void UserInterfaceOptionsState::setControlKeyRequired(bool onoff) {
    bool debug = false;
    bool old =   _controlKeyRequired;
    bool newControlKeyRequired = onoff;
    TRACECF_STARTING(debug, "old = %s, new = %s", SBOOL(_controlKeyRequired), SBOOL(onoff));

    if (newControlKeyRequired != old) {
       _controlKeyRequired = newControlKeyRequired;
       TRACECF_EVENT(debug, "emitting controlKeyRequired_changed(%s)", SBOOL(_controlKeyRequired));
       emit controlKeyRequired_changed(_controlKeyRequired);
    }
    TRACECF_DONE(debug, "");
}

void init_user_interface_options_state() {
   bool debug = false;
   DBGF(debug, "Starting");
   RTTI_ADD_METHOD(UserInterfaceOptionsState::UserInterfaceOptionsState);
   DBGF(debug, "Done");
}
