/** @file feature_widget_header.h */

// Copyright (C) 2018-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef FEATURE_WIDGET_HEADER_H_
#define FEATURE_WIDGET_HEADER_H_

#include <QFrame>
#include <QResizeEvent>

#include "base/ddcui_core.h"

class FeatureWidgetHeader : public QFrame {
   Q_OBJECT

public:
   explicit FeatureWidgetHeader(QWidget * parent = nullptr);
   virtual ~FeatureWidgetHeader();

protected:
    void resizeEvent(QResizeEvent * event) override;

private:
    void layoutWidget();

private:     // member variables
    const char * _cls;

};

#endif /* FEATURE_WIDGET_HEADER_H_ */
