// features_scrollarea.cpp

// Copyright (C) 2019-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#include <QScrollArea>
#include <QSize>
#include "base/widget_debug.h"
#include "feature_scrollarea/features_scrollarea_contents.h"
#include "base/ddcui_core.h"

#include "feature_scrollarea/features_scrollarea.h"

static bool showWidgetDimensions = false;
static bool traceResizeEvents = false;

void FeaturesScrollArea::layoutWidget() {
   if (debugLayout) {
      setStyleSheet("background-color:maroon;");
      static bool widgetDimensionsReported = false;
      if (showWidgetDimensions && !widgetDimensionsReported) {
         reportWidgetDimensions(this, _cls, __func__, "FeatureScrollAreaContents dimensions");
         widgetDimensionsReported = true;
      }
   }
}

FeaturesScrollArea::FeaturesScrollArea(QWidget *parent)
    : QScrollArea(parent)
{
   _cls = metaObject()->className();
   // TRACE("Executing");
   layoutWidget();
}

FeaturesScrollArea::~FeaturesScrollArea()
{
}

void FeaturesScrollArea::resizeEvent(QResizeEvent * evt)
{
   QSize oldSz = evt->oldSize();
   QSize newSz = evt->size();
   QWidget * contents = widget();
   QSize contentsSize = contents->size();
   // TODO: get calculate the actual scrollbar width
   QSize newSize = QSize(contentsSize.width()-24, contentsSize.height());
   contents->resize(newSize);
   evt->ignore();

   if (traceResizeEvents) {
      TRACEC_EVENT("old size = %d, %d", oldSz.width(), oldSz.height());
      TRACEC_EVENT("new size = %d, %d", newSz.width(), newSz.height());
      TRACEC_EVENT("Current contents size %d,%d", contentsSize.width(), contentsSize.height());
      TRACEC_EVENT("Resizing contents to  %d,%d", newSize.width(), newSize.height());
   }
}

