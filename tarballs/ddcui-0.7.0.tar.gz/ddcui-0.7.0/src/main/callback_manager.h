/** \file callback_manager.h
 *
 *  This class exists so that code that actually handles display
 *  changes does not execute on the callback function thread,
 *  allowing the callback to return quickly.
 */

// Copyright (C) 2024-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef CALLBACK_MANAGER_H_
#define CALLBACK_MANAGER_H_

#include <QObject>

#include <ddcutil_c_api.h>

#include "config.h"

#include "main/mainwindow.h"


class CallbackManager : public QObject
{
    Q_OBJECT

public:
    static CallbackManager& instance();

    void registerCallbacks(MainWindow* mainWindow);
    void emitDisplayChanged(DDCA_Display_Status_Event evt);

private:
   CallbackManager();
   // No need for destructor.  Created once for life of the program.
   const char *                 _cls;


public:
   signals:
   void displayChanged(DDCA_Display_Status_Event evt);

};

void init_callback_manager();

#endif /* CALLBACK_MANAGER_H_ */
