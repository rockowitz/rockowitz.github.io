// api_services_intenral.h

// Copyright (C) 2021 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef API_SERVICES_INTERNAL_H_
#define API_SERVICES_INTERNAL_H_

void init_api_services();

#endif /* API_SERVICES_INTERNAL_H_ */
