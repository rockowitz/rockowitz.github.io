// api_services_internal.c

#include <stdio.h>

#include "api_capabilities_internal.h"

// Copyright (C) 2021 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

void init_api_services() {
   // printf("(%s) Executing...\n", __func__);
   // init_api_capabilities();
}

