// query_sysenv_original_sys_scans.h

// Copyright (C) 2021 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef QUERY_SYSENV_ORIGINAL_SYS_SCANS_H_
#define QUERY_SYSENV_ORIGINAL_SYS_SCANS_H_

void dump_original_sys_scans();

#endif /* QUERY_SYSENV_ORIGINAL_SYS_SCANS_H_ */
