/** @file glib_util.h
 *
 *  Utility functions for glib.
 */

// Copyright (C) 2014-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later


#ifndef GLIB_UTIL_H_
#define GLIB_UTIL_H_

/** \cond */
#include <glib-2.0/glib.h>
#include <stdio.h>
/** \endcond */

#ifdef __cplusplus
extern "C" {
#endif

/** Documents the element type of a #GPtrArray.
 *
 *  Resolves to plain `GPtrArray`, so it is a comment the compiler will not let
 *  drift out of the declaration -- it records what the array holds, nothing
 *  more.  There is no type checking: the elements remain `gpointer`, and
 *  assigning a GPTRARRAY(A) to a GPTRARRAY(B) is not an error.
 *
 *  @param  _type  element type the array holds, e.g. GPTRARRAY(Sys_Drm_Connector) *
 */
#define GPTRARRAY(_type) GPtrArray

gpointer *
g_list_to_g_array(
      GList * glist,
      guint * length);

gint
gaux_ptr_scomp(
      gconstpointer a,
      gconstpointer b);

gint
gaux_ptr_intcomp(
      gconstpointer a,
      gconstpointer b);

void *
get_thread_dynamic_buffer(
      GPrivate * buf_key_ptr,
      GPrivate * bufsz_key_ptr,
      guint      required_size);

void *
get_thread_fixed_buffer(
      GPrivate * buf_key_ptr,
      guint      required_size);

GPtrArray *
gaux_ptr_array_truncate(
      GPtrArray * gpa,
      int         limit);

// Future:
typedef  gpointer (*GAuxDupFunc)(gpointer src);

GPtrArray *
gaux_ptr_array_append_array(
      GPtrArray * dest,
      GPtrArray * src,
      GAuxDupFunc dup_func);

GPtrArray *
gaux_ptr_array_join(
      GPtrArray *    gpa1,
      GPtrArray *    gpa2,
      GAuxDupFunc    dup_func,
      GDestroyNotify element_free_func);

GPtrArray *
gaux_ptr_array_copy(
      GPtrArray *    src,
      GAuxDupFunc    dup_func,
      GDestroyNotify element_free_func);

GPtrArray *
gaux_deep_copy_string_array(
      GPtrArray * old_names);

GPtrArray *
gaux_ptr_array_from_null_terminated_array(
      gpointer *     src,
      GAuxDupFunc    dup_func,
      GDestroyNotify element_free_func);

gboolean
gaux_streq(              // alternative to g_str_equal(), has GEqualFunc signature
      gconstpointer a,
      gconstpointer b);

gboolean
gaux_ptr_array_find_with_equal_func(
      GPtrArray *    haystack,
      gconstpointer  needle,
      GEqualFunc     equal_func,
      guint *        index_loc);

#define G_PTR_ARRAY_ADD_STRING(_collector, _format, ...) \
do { \
      g_ptr_array_add(_collector, g_strdup_printf(_format, ##__VA_ARGS__)); \
} while(0)

#ifdef __cplusplus
}
#endif

#endif /* GLIB_UTIL_H_ */
