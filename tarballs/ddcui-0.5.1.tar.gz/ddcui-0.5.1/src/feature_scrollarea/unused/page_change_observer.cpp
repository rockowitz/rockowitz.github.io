#include "unused/page_change_observer.h"

#include <string.h>
#include <stdio.h>
#include <iostream>

// PageChangeObserver::PageChangeObserver() {}

// PageChangeObserver::~PageChangeObserver() {}

// void PageChangeObserver::PageChanged(int pageno) {
//     printf("(PageChangeObserver::%s) feature_code: %d\n", __func__, pageno ); fflush(stdout);
//    //  std::cout << "    objectName: " << objectName.toStdString() << std::endl;
// }
