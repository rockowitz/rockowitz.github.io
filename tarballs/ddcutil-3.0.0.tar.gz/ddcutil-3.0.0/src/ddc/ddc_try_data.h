/** @file ddc_try_data.h
 *
 *  Maintains statistics on DDC retries and also maxtries settings.
 *
 *  These statistics are global, not broken out by thread.
 */

// Copyright (C) 2014-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef DDC_TRY_DATA_H_
#define DDC_TRY_DATA_H_

#include <stdbool.h>

#include "ddcutil_types.h"

#include "base/displays.h"
#include "base/stats.h"

void     try_data_init_retry_type(Retry_Operation retry_type, Retry_Op_Value maxtries);
void     init_ddc_try_data();
Retry_Op_Value
         try_data_get_maxtries(Retry_Operation retry_type);
void     try_data_set_maxtries(Retry_Operation retry_type, Retry_Op_Value new_maxtries);
void     try_data_reset_all();
void     try_data_record_tries(Display_Handle * dh, Retry_Operation retry_type, DDCA_Status rc, int tryct);
void     try_data_report(Retry_Operation retry_type, int depth);

void     ddc_report_max_tries(int depth);
void     ddc_report_ddc_stats(int depth);

#endif /* DDC_TRY_DATA_H_ */
