/** @file dw_poll.c
 *
 *  Watch for display changes without using UDEV
 */

// Copyright (C) 2018-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#include "config.h"
#include "public/ddcutil_types.h"

/** \cond */
#include <assert.h>
#include <glib-2.0/glib.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef USE_X11
#include <X11/Xlib.h>
#endif

#include "util/common_inlines.h"
#include "util/data_structures.h"
#include "util/dbus_util.h"
#include "util/linux_util.h"
#include "util/report_util.h"
#include "dw_suspend_resume.h"
#include "util/timestamp.h"
#include "util/traced_function_stack.h"

#include "base/core.h"
#include "base/displays.h"
#include "base/drm_connector_state.h"
#include "base/i2c_bus_base.h"
#include "base/rtti.h"
#include "base/sleep.h"
/** \endcond */

#include "sysfs/sysfs_dpms.h"

#include "i2c/i2c_bus_collections.h"
#include "i2c/i2c_bus_core.h"

#include "ddc/ddc_displays.h"

#include "dw_common.h"
#include "dw_recheck.h"
#include "dw_status_events.h"
#include "dw_udev.h"
#ifdef USE_X11
#include "dw_xevent.h"
#endif

#include "dw_poll.h"


// Trace class for this file
static DDCA_Trace_Group TRACE_GROUP = DDCA_TRC_CONN;

int  nonudev_poll_loop_millisec = DEFAULT_UDEV_WATCH_LOOP_MILLISEC;   // 2000;
// Atomic to handle concurrent reads in recheck worker threads and writes by dw_set_display_watch_settings()
_Atomic uint16_t  retry_thread_sleep_factor_millisec = WATCH_RETRY_THREAD_SLEEP_FACTOR_MILLISEC;
bool stabilize_added_buses_w_edid = false;  // if set, stabilize when displays added as well as removed
bool recheck_thread_active = false;
int  display_watch_thread_initial_delay = 0;

STATIC void dw_process_screen_change_event(
      BS256*      p_bs_attached_buses,
      BS256*      p_bs_buses_w_edid,
      GArray *    deferred_events,
      GPtrArray * displays_to_recheck
      )
{
   bool debug = false;
   DBGTRC_STARTING(debug, TRACE_GROUP, "*p_bs_old_attached_buses -> %s",
                         bs256_to_string_decimal_t(*p_bs_attached_buses, "", ","));
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "*p_bs_buses_w_edid   -> %s",
                         bs256_to_string_decimal_t(*p_bs_buses_w_edid,   "", ",")) ;

   BS256 bs_old_attached_buses = *p_bs_attached_buses;
   BS256 bs_old_buses_w_edid   = *p_bs_buses_w_edid;
   assert(bs256_is_subset(bs_old_buses_w_edid, bs_old_attached_buses));

   // Mutex for next 2 assignments?
   // Guarantee: bs_new_buses_w_edid is a subset of bs_new_attached_buses
   BS256 bs_new_attached_buses = i2c_detect_attached_buses_as_bitset();
   // eacces_seen remains false unless rescan_on_eacces is set, so the rescan
   // loop below executes only when that global is set
   bool eacces_seen = false;
   BS256 bs_new_buses_w_edid   = i2c_filter_buses_w_edid_as_bitset(bs_new_attached_buses,
                                       (rescan_on_eacces) ? &eacces_seen : NULL);

   // After resume from sleep there is a window in which the /dev/i2c devices
   // exist but udev has not yet reapplied uaccess ACLs, so open() fails with
   // EACCES.  In that state a connected monitor is indistinguishable from a
   // disconnected one; processing the scan would emit a spurious mass
   // disconnect, followed by a reconnect once the ACLs are restored, each
   // with its full stabilization and recheck cascade.  Rescan until the
   // window passes; if EACCES persists, fall through and process the scan
   // as read (the pre-existing behavior).
   int eacces_rescan_ct = 0;
   const int max_eacces_rescan_ct = 3;
   while (eacces_seen && eacces_rescan_ct < max_eacces_rescan_ct && !terminate_watch_thread) {
      eacces_rescan_ct++;
      DECORATED_SYSLOG(DDCA_SYSLOG_WARNING,
            "EACCES opening /dev/i2c device(s). Rescanning (%d of %d)...",
            eacces_rescan_ct, max_eacces_rescan_ct);
      dw_split_sleep(1000);
      if (terminate_watch_thread)
         break;
      bs_new_attached_buses = i2c_detect_attached_buses_as_bitset();
      eacces_seen = false;
      bs_new_buses_w_edid = i2c_filter_buses_w_edid_as_bitset(bs_new_attached_buses, &eacces_seen);
   }
   if (eacces_seen)
      DECORATED_SYSLOG(DDCA_SYSLOG_ERROR,
            "EACCES opening /dev/i2c device(s) persists. Processing possibly inaccurate scan.");

   assert(bs256_is_subset(bs_new_buses_w_edid, bs_new_attached_buses));

   Bit_Set_256 bs_added_buses_w_edid     = bs256_and_not(bs_new_buses_w_edid, bs_old_buses_w_edid);
   Bit_Set_256 bs_removed_buses_w_edid   = bs256_and_not(bs_old_buses_w_edid, bs_new_buses_w_edid);
   Bit_Set_256 bs_added_attached_buses   = bs256_and_not(bs_new_attached_buses, bs_old_attached_buses);
   Bit_Set_256 bs_removed_attached_buses = bs256_and_not(bs_old_attached_buses, bs_new_attached_buses);
#ifdef TMI
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_old_buses_w_edid(0): %s",
                             bs256_to_string_decimal_t(bs_old_buses_w_edid, "", ","));
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_new_buses_edid(0): %s",
                             bs256_to_string_decimal_t(bs_new_buses_w_edid, "", ","));
#endif

   if ( bs256_count(bs_removed_buses_w_edid) > 0 ||
        (stabilize_added_buses_w_edid &&  bs256_count(bs_added_buses_w_edid) > 0)) {
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_old_attached_buses: %s", BS256_REPR(bs_old_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_new_attached_buses: %s", BS256_REPR(bs_new_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_old_buses_w_edid: %s",   BS256_REPR(bs_old_buses_w_edid));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_new_buses_edid: %s",   BS256_REPR(bs_new_buses_w_edid));

      bs_new_buses_w_edid = dw_stabilized_buses_bs(bs_new_buses_w_edid, bs256_count(bs_removed_buses_w_edid));

      bs_added_buses_w_edid     = bs256_and_not(bs_new_buses_w_edid, bs_old_buses_w_edid);
      bs_removed_buses_w_edid   = bs256_and_not(bs_old_buses_w_edid, bs_new_buses_w_edid);
      bs_added_attached_buses   = bs256_and_not(bs_new_attached_buses, bs_old_attached_buses);
      bs_removed_attached_buses = bs256_and_not(bs_old_attached_buses, bs_new_attached_buses);
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "After stabilization:");
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_old_attached_buses: %s", BS256_REPR(bs_old_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_new_attached_buses: %s", BS256_REPR(bs_new_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_old_buses_w_edid:   %s", BS256_REPR(bs_old_buses_w_edid));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_new_buses_edid:     %s", BS256_REPR(bs_new_buses_w_edid));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_added_attached_buses:   %s", BS256_REPR(bs_added_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_removed_attached_buses:   %s", BS256_REPR(bs_removed_attached_buses));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_added_buses_w_edid: %s", BS256_REPR(bs_added_buses_w_edid));
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bs_removed_buses_w_edid: %s", BS256_REPR(bs_removed_buses_w_edid));
   }
   bs_old_buses_w_edid   = bs_new_buses_w_edid;
   bs_old_attached_buses = bs_new_attached_buses;

#ifdef MOVE_TO_HOTPLUG_CHANGE_HANDLER
   if (bs256_count(bs_removed_attached_buses) > 0 ) {
      Bit_Set_256_Iterator iter = bs256_iter_new(bs_removed_attached_buses);
      while(true) {
         int busno = bs256_iter_next(iter);
         if (busno < 0)
            break;

         i2c_remove_bus_by_busno(busno);
      }
   }
#endif

   bool hotplug_change_handler_emitted = false;
   bool connected_buses_w_edid_changed = bs256_count(bs_removed_buses_w_edid) > 0 ||
                                       bs256_count(bs_added_buses_w_edid) > 0;
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "connected_buses_changed = %s", SBOOL(connected_buses_w_edid_changed));
   if (connected_buses_w_edid_changed) {
      hotplug_change_handler_emitted = dw_hotplug_change_handler(
                                           bs_removed_attached_buses,
                                           bs_added_attached_buses,
                                           bs_removed_buses_w_edid,
                                           bs_added_buses_w_edid,
                                           deferred_events,
                                           displays_to_recheck);
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "hotplug_change_handler_emitted = %s",
            sbool (hotplug_change_handler_emitted));
   }

#ifdef WATCH_ASLEEP
   if (watch_dpms) {
      // DBGTRC_NOPREFIX(debug, TRACE_GROUP, "Before ddc_check_bus_asleep(), bs_sleepy_buses: %s",
      //      BS256_REPR(bs_sleepy_buses));
      // emits dpms events directly or places them on deferred_events queue
      bs_sleepy_buses = ddc_i2c_check_bus_asleep(
            bs_old_buses_w_edid, bs_sleepy_buses, deferred_events);
      // DBGTRC_NOPREFIX(debug, TRACE_GROUP, "After ddc_check_bus_asleep(), bs_sleepy_buses: %s",
      //       BS256_REPR(bs_sleepy_buses));
   }
#endif

#ifdef ALT
   if (watch_dpms) {
      for (int ndx = 0; ndx < all_i2c_buses->len; ndx++) {
          I2C_Bus_Info * businfo = g_ptr_array_index(all_i2c_buses, ndx);
          // DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "ndx=%d, businfo=%p", ndx, businfo);
          // DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bus=%d", businfo->busno);
          if (businfo->flags & I2C_BUS_ADDR_0X50) {
              // DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "bus=%d, I2C_BUS_ADDR_0X50 set", businfo->busno);
              bool is_dpms_asleep = dpms_check_drm_asleep_by_businfo(businfo);
              DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "busno=%d, is_dpms_asleep=%s, last_checked_dpms_asleep=%s",
                 businfo->busno, sbool(is_dpms_asleep), sbool(businfo->last_checked_dpms_asleep));
              if (is_dpms_asleep != businfo->last_checked_dpms_asleep) {
                 Display_Ref * dref = ddc_get_dref_by_busno_or_connector(businfo->busno, NULL, /*ignore_invalid*/ true);
                 assert(dref);
                 DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "sleep change event for dref=%p->%s", dref, dref_repr_t(dref));
                 DDCA_Display_Event_Type event_type = (is_dpms_asleep) ? DDCA_EVENT_DPMS_ASLEEP : DDCA_EVENT_DPMS_AWAKE;
                 dw_emit_or_queue_display_status_event(event_type, dref->drm_connector, dref, dref->io_path, NULL);
                 businfo->last_checked_dpms_asleep = is_dpms_asleep;
              }
           }
       }
   }
#endif

   *p_bs_attached_buses  = bs_old_attached_buses;
   *p_bs_buses_w_edid    = bs_old_buses_w_edid;

   DBGTRC_DONE(debug, TRACE_GROUP, "*p_bs_old_attached_buses -> %s",
         bs256_to_string_decimal_t(*p_bs_attached_buses, "", ","));
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "*p_bs_buses_w_edid -> %s",
         bs256_to_string_decimal_t(*p_bs_buses_w_edid,   "", ","));
}


STATIC void dw_invoke_process_screen_change_event(
      BS256*     bs_old_attached_buses_loc,
      BS256*     bs_old_buses_w_edid_loc,
      GArray* deferred_events,
      GPtrArray* displays_to_recheck)
{
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "");

   // Announce the pending event before acquiring master_dw_mutex, so that
   // recheck worker threads defer starting new probes (which can hold the
   // mutex for seconds) rather than queueing in front of event processing.
   dw_event_processing_pending = true;
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "Locking master_dw_mutex, thread_id = %d", TID());
   g_mutex_lock(&master_dw_mutex);

   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "locking process_event_mutex");
   g_mutex_lock(&process_event_mutex);
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Processing screen change event");
   dw_process_screen_change_event(bs_old_attached_buses_loc, bs_old_buses_w_edid_loc,
                               deferred_events, displays_to_recheck);
   if (displays_to_recheck->len > 0) {
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "handling displays_to_recheck");
      int len = displays_to_recheck->len;
      for (int ndx = len-1; ndx >= 0; ndx--) {
         dw_put_recheck_queue(g_ptr_array_index(displays_to_recheck, ndx));
         g_ptr_array_remove_index(displays_to_recheck, ndx);
      }
#ifdef OLD
      Recheck_Displays_Data * rdd = calloc(1, sizeof(Recheck_Displays_Data));
      rdd->displays_to_recheck = displays_to_recheck;
      rdd->deferred_event_queue = deferred_events;
      g_thread_new("display_recheck_thread",             // optional thread name
                   ddc_recheck_displays_func,
                   rdd);
      displays_to_recheck = g_ptr_array_new();
#endif
   }
   g_mutex_unlock(&process_event_mutex);
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "unlocked process_event_mutex");

   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "Unlocking master_dw_mutex, thread_id = %d", TID());
   g_mutex_unlock(&master_dw_mutex);
   dw_event_processing_pending = false;

   DBGTRC_DONE(debug, DDCA_TRC_NONE, "");
}



/** Function that executes in the display watch thread.
 *
 *  @param   data  pointer to a #Watch_Display_Data struct
 */
gpointer dw_watch_display_connections(gpointer data) {
   bool debug = false;
   bool use_deferred_event_queue = false;
   Watch_Displays_Data * wdd = data;
   assert(wdd && memcmp(wdd->marker, WATCH_DISPLAYS_DATA_MARKER, 4) == 0);
   assert(wdd->watch_mode == Watch_Mode_Xevent  || wdd->watch_mode == Watch_Mode_Poll || wdd->watch_mode == Watch_Mode_Udev);
#ifdef USE_X11
   if (wdd->watch_mode == Watch_Mode_Xevent)
      assert(wdd->evdata);
#endif
   GPtrArray * displays_to_recheck = g_ptr_array_new();

   DBGTRC_STARTING(debug, TRACE_GROUP,
         "Caller process id: %d, caller thread id: %d, our thread id: %d, event_classes=0x%02x, terminate_using_x11_event=%s",
         wdd->main_process_id, wdd->main_thread_id, tid(), wdd->event_classes, sbool(terminate_using_x11_event));
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "Watching for display connection events: %s",
         sbool(wdd->event_classes & DDCA_EVENT_CLASS_DISPLAY_CONNECTION));
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "watch_mode = %s, watch_loop_millisec=%d", watch_mode_name(wdd->watch_mode), wdd->watch_loop_millisec);
#ifdef WATCH_DPMS
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Watching for dpms events: %s",
          sbool(wdd->event_classes & DDCA_EVENT_CLASS_DPMS));
#endif

   if (display_watch_thread_initial_delay > 0) {
      DUAL_MSGNV(debug, DDCA_SYSLOG_NOTICE, "Waiting an extra %d ms at start of function",
            display_watch_thread_initial_delay);
      SLEEP_MILLIS_WITH_STATS(display_watch_thread_initial_delay);
   }

   // may need to wait on startup
   while (!all_i2c_buses) {
      DUAL_MSGN(debug, DDCA_SYSLOG_NOTICE, "Waiting 500 ms for all_i2c_buses");
      SLEEP_MILLIS_WITH_STATS(500);
   }

   pid_t cur_pid = getpid();
   pid_t cur_tid = get_thread_id();
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Our process id: %d, our thread id: %d", cur_pid, cur_tid);

#ifdef WATCH_DPMS
   bool watch_dpms = wdd->event_classes & DDCA_EVENT_CLASS_DPMS;
   BS256 bs_sleepy_buses   = EMPTY_BIT_SET_256;
#endif

   BS256 bs_old_attached_buses = i2c_buses_bitset_from_businfo_array(all_i2c_buses, false);
   BS256 bs_old_buses_w_edid   = i2c_buses_bitset_from_businfo_array(all_i2c_buses, true);
   DBGTRC_NOPREFIX(debug, TRACE_GROUP, "Initial i2c buses with edids: %s",
          BS256_REPR(bs_old_buses_w_edid));
#ifdef TMI
   if (IS_DBGTRC(debug, DDCA_TRC_NONE)) {
       rpt_vstring(0, "Initial I2C buses:");
       i2c_dbgrpt_buses_summary(1);
       rpt_vstring(0, "Initial Display Refs:");
       ddc_dbgrpt_display_refs_summary(true,     // include_invalid_displays
                                       false,    // report_businfo
                                       1);       // depth
       if (use_drm_connector_states) {
          rpt_vstring(0, "Initial DRM connector states");
          report_drm_connector_states_basic(/*refresh*/ true, 1);
       }
    }
#endif

   GArray * deferred_events = NULL;
   if (use_deferred_event_queue) {
      deferred_events = g_array_new(false,      // zero_terminated
                                    false,      // clear
                                    sizeof(DDCA_Display_Status_Event));
   }

   if (wdd->watch_mode == Watch_Mode_Udev) {
      dw_udev_setup();
   }

   bool skip_next_sleep = false;
   int slept_millisec = 0;   // will contain length of final sleep

   /** Set when the post-scan drain below took events off the udev queue.
    *
    *  Those events are held, not discarded: the next pass skips the wait in
    *  dw_udev_watch() and scans directly, so every drained event is still
    *  answered by a scan that reads hardware state after the event arrived.
    *  Discarding them instead would lose a hotplug that occurred during the
    *  preceding scan, which is why this is a flag rather than a plain drain.
    */
   bool rescan_without_waiting = false;

   while (!terminate_watch_thread) {
      if (deferred_events && deferred_events->len > 0) {
         dw_emit_deferred_events(deferred_events);
         skip_next_sleep = true;
      }
      else {     // skip polling loop sleep if deferred events were output
         if (!skip_next_sleep && wdd->watch_mode == Watch_Mode_Poll) {
            slept_millisec = dw_split_sleep(wdd->watch_loop_millisec);
         }
         skip_next_sleep = false;
      }
      if (terminate_watch_thread)
         continue;
      dw_terminate_if_invalid_thread_or_process(cur_pid, cur_tid);

      if (wdd->watch_mode == Watch_Mode_Udev) {
         if (rescan_without_waiting) {
            // Events are already in hand from the post-scan drain below.
            // Waiting in poll() for another would be wrong -- those events
            // would then never be answered -- and the coalesce pause inside
            // dw_udev_watch() would be redundant, the drain having already
            // collected the burst it exists to accumulate.
            rescan_without_waiting = false;
            DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE,
                  "Scanning directly, events drained after the previous scan");
         }
         else {
            // sem_wait(&sem);
            // close the door behind us:
            // sem_post(&sem);
            dw_udev_watch(wdd->watch_loop_millisec);
            if (terminate_watch_thread)
               continue;
         }
      }

#ifdef USE_X11
      else
      if (wdd->watch_mode == Watch_Mode_Xevent) {
         if (terminate_using_x11_event) {
            bool event_found = dw_next_X11_event_of_interest(wdd->evdata);
            // either display changed or terminate signaled
            DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "event_found=%s", sbool(event_found));
            if (!event_found) {
               terminate_watch_thread = true;
               continue;
            }
         }
         else {
            bool event_found = dw_detect_xevent_screen_change(wdd->evdata,  wdd->watch_loop_millisec);
            if (event_found)
               DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Screen change event occurred");
            else
               continue;
         }
      }
#endif

      if (!skip_settling_pauses &&
            wdd->watch_mode != Watch_Mode_Udev) {  // for Udev mode, pause occurs in dw_udev_watch()
         dw_pause_if_recently_resumed_from_sleep(pause_after_resume_ms);
      }

      dw_invoke_process_screen_change_event(&bs_old_attached_buses, &bs_old_buses_w_edid,
            deferred_events, displays_to_recheck);

      // A scan takes on the order of a second, and after a resume udev keeps
      // emitting device re-registration events for longer than that, so events
      // reliably arrive while the scan is running.  The coalesce pause in
      // dw_udev_watch() cannot absorb them: it closes before the scan starts.
      // Left queued, they wake the loop immediately -- in the logs, poll()
      // returns about 30 ms after a scan completes -- and buy a second full
      // pause and scan.
      //
      // Draining here collapses that burst into one iteration, and the flag is
      // what keeps it safe: an event received while a scan was running may
      // describe a change the scan read too early to see, so it must still be
      // answered.  The next pass therefore scans rather than waits.  Nothing
      // is discarded on the strength of a guess about what an event means.
      if (wdd->watch_mode == Watch_Mode_Udev && !terminate_watch_thread) {
         if (dw_udev_drain() > 0)
            rescan_without_waiting = true;
      }
   } // while()

   if (wdd->watch_mode == Watch_Mode_Udev) {
      dw_udev_teardown();
   }

   g_ptr_array_free(displays_to_recheck, false);
   dw_free_watch_displays_data(wdd);
   if (deferred_events)
      g_array_free(deferred_events, true);
#ifdef WATCH_DPMS
   if (watch_dpms)
      g_ptr_array_free(sleepy_connectors, true);
#endif

   // n. slept == 0 if no sleep was performed
   DBGTRC_DONE(debug, TRACE_GROUP,
         "Terminating thread.  Final polling sleep was %d millisec.", slept_millisec);
   free_current_traced_function_stack();
   // g_thread_exit(0);
   // assert(false);    // avoid clang warning re wdd use after free
   // return NULL;    // satisfy compiler check that value returned
   return NULL;
}


void init_dw_poll() {
   RTTI_ADD_FUNC(dw_watch_display_connections);
   RTTI_ADD_FUNC(dw_invoke_process_screen_change_event);
   RTTI_ADD_FUNC(dw_process_screen_change_event);
}
