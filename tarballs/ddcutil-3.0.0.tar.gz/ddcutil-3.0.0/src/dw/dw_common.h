/** @file dw_common.h */

// Copyright (C) 2018-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef DW_COMMON_H_
#define DW_COMMON_H_

#include <glib-2.0/glib.h>
#include <sys/types.h>

#include "util/data_structures.h"

#include "base/displays.h"

#ifdef USE_X11
#include "dw_xevent.h"
#endif

extern _Atomic uint16_t  initial_stabilization_millisec;
extern _Atomic uint16_t  pause_after_add_ms;
extern _Atomic uint16_t  drain_pause_ms;
extern _Atomic uint16_t  stabilization_poll_millisec;
extern _Atomic uint16_t  udev_watch_loop_millisec;
extern _Atomic uint16_t  poll_watch_loop_millisec;
extern _Atomic uint16_t  xevent_watch_loop_millisec;
extern _Atomic bool      terminate_watch_thread;
extern _Atomic bool      terminate_using_x11_event;
extern _Atomic bool      dw_event_processing_pending;
extern GMutex             master_dw_mutex;
extern GMutex             process_event_mutex;
extern bool               use_drm_connector_states;
extern bool               force_recheck;
extern bool               rescan_on_eacces;
extern bool               skip_settling_pauses;

// If true, blocking waits in the watch thread poll() the relevant fd together
// with terminate_watch_thread_fd instead of sleeping in timed polling loops.
extern _Atomic bool      use_eventfd;
// If true, dw_split_sleep() performs a single poll() on
// terminate_watch_thread_fd instead of sleeping in 200 ms segments.
extern _Atomic bool      split_sleep_eventfd;
// eventfd signaled when watch thread termination is requested, -1 if not created
extern int                terminate_watch_thread_fd;

void      dw_create_terminate_eventfd();
void      dw_signal_terminate_eventfd();
void      dw_close_terminate_eventfd();

uint32_t  dw_calc_watch_loop_millisec(DDC_Watch_Mode watch_mode);
uint32_t  dw_split_sleep(int watch_loop_millisec);
void      dw_terminate_if_invalid_thread_or_process(pid_t cur_pid, pid_t cur_tid);

#ifdef UNUSED
typedef void (*Display_Change_Handler)(
                 GPtrArray *          buses_removed,
                 GPtrArray *          buses_added,
                 GPtrArray *          connectors_removed,
                 GPtrArray *          connectors_added);
#endif 

#define WATCH_DISPLAYS_DATA_MARKER "WDDM"
typedef struct {
   char                     marker[4];
   pid_t                    main_process_id;
   pid_t                    main_thread_id;
   DDCA_Display_Event_Class event_classes;
   DDC_Watch_Mode           watch_mode;
   int                      watch_loop_millisec;
#ifdef USE_X11
   XEvent_Data *            evdata;
#endif
  } Watch_Displays_Data;

void dw_free_watch_displays_data(Watch_Displays_Data * wdd);


#ifdef UNUSED
#define CALLBACK_DISPLAYS_DATA_MARKER "CDDM"
typedef struct {
   char                     marker[4];
   pid_t                    main_process_id;  //?
// pid_t                    main_thread_id;   //?
  } Callback_Displays_Data;

Callback_Displays_Data * dw_new_callback_displays_data();
void dw_free_callback_displays_data(Callback_Displays_Data * rdd);
#endif


#ifdef UNUSED
typedef struct {
   Bit_Set_256 all_displays;
   Bit_Set_256 displays_w_edid;
}  Bit_Set_256_Pair;
bool bs256_pair_eq(Bit_Set_256_Pair pair1, Bit_Set_256_Pair pair2);
#endif

Bit_Set_256
dw_stabilized_buses_bs(Bit_Set_256 bs_prior, bool some_displays_disconnected);

#ifdef WATCH_ASLEEP
Bit_Set_256 ddc_i2c_check_bus_asleep(
      Bit_Set_256  bs_active_buses,
      Bit_Set_256  bs_sleepy_buses,
      GArray*      events_queue);
#endif

void dw_emit_deferred_events(GArray * deferred_events);

bool dw_hotplug_change_handler(
      Bit_Set_256    bs_attached_buses_removed,
      Bit_Set_256    bs_attached_buses_added,
      Bit_Set_256    bs_buses_w_edid_removed,
      Bit_Set_256    bs_buses_w_edid_added,
      GArray * events_queue,
      GPtrArray * drefs_to_recheck);

void record_active_callback_thread(GThread* thread);
void remove_active_callback_thread(GThread* thread);
int  active_callback_thread_ct();

/** Bound on how many times a settling pause is retaken after being spent by a
 *  suspend.  More than one repeat means a second suspend began while settling
 *  from the first.
 */
#define MAX_SETTLING_PAUSE_ATTEMPTS 3

bool dw_sleep_spent_by_suspend(int millisec);
int dw_pause_if_recently_resumed_from_sleep(int min_interval_ms);


void init_dw_common();

#endif /* DW_COMMON_H_ */
