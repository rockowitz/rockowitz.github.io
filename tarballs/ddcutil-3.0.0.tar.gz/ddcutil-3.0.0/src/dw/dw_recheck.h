/** @file dw_recheck.h
 *
 *  Process the queue of display references added in
 *  the main loop for which DDC communication was
 *  not immediately detected as  enabled.
 */

// Copyright (C) 2025-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#ifndef DW_RECHECK_H_
#define DW_RECHECK_H_

#include <glib-2.0/glib.h>

#include "base/displays.h"

#define RECHECK_DISPLAYS_DATA_MARKER "RDDM"
typedef struct {
   char                     marker[4];
#ifdef UNUSED
   pid_t                    main_process_id;  //?
   pid_t                    main_thread_id;   //?
#endif
  } Recheck_Displays_Data;

void     dw_free_recheck_displays_data(Recheck_Displays_Data * rdd);
void     dw_put_recheck_queue(Display_Ref* dref);
gpointer dw_recheck_displays_func(gpointer data);

// NEW WAY:
gpointer dw_manager_recheck_thread_func(gpointer data);

void     init_dw_recheck();
void     terminate_dw_recheck();

#endif /* DW_RECHECK_H_ */
