/** @file i2c_bus_sysfs.c
 *  Sysfs based functions for I2C buses
 *
 *  Functions that determine properties of an I2C bus, or of the display
 *  attached to it, by reading sysfs rather than by communicating with the
 *  display over the bus.
 */

// Copyright (C) 2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#include "config.h"
#include "base/parms.h"

/** \cond */
#include <assert.h>
#include <glib-2.0/glib.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/** \endcond */

#include "util/coredefs.h"
#include "util/edid.h"
#include "util/file_util.h"
#include "util/glib_util.h"
#include "util/report_util.h"
#include "util/string_util.h"
#include "util/sysfs_util.h"

#include "base/core.h"
#include "base/i2c_bus_base.h"
#include "base/rtti.h"

#include "sysfs/sysfs_simple.h"
#include "sysfs/sysfs_base.h"
#include "sysfs/sysfs_basic_drm_connector.h"
#include "sysfs/sysfs_sys_drm_connector.h"

#include "i2c_bus_sysfs.h"

/* The DRM connectors are read once at the start of display detection, used for
 * the lookups detection performs, and the array then discarded.  One scan,
 * where walking /sys/class/drm per lookup costs buses x connectors: measured,
 * syscalls under /sys/class/drm for one detect, 147 against 380 on i915 and
 * 182 against 518 on nvidia, for the same connector names and ids.
 *
 * Nothing maintains the array, because it does not outlive the detection that
 * built it.  No lock is needed, since nothing writes it after construction; it
 * cannot go stale, being discarded before anything could; and there is no
 * removal or refresh path.  Every defect found while this code was being
 * written came from maintaining an array that persisted -- see
 * MAINTAINED_CONNECTOR_ARRAY, which parks that version for reference.
 *
 * Lookups made when no snapshot is in use -- on the hotplug path, and from
 * i2c_detect_single_bus() -- fall back to
 * find_sys_drm_connector_by_busno_or_edid_sysfs(), which walks the connector
 * directories.  That is where its simplicity is worth having and its cost is
 * not paid per bus.
 */

/* True only while algorithm 2's snapshot is in use, i.e. between the scan at
 * the top of i2c_detect_buses0() and the discard at the bottom.  Tested rather
 * than the array's mere presence, because other callers rebuild it lazily and
 * a rebuilt array is not the snapshot this algorithm reasons about.
 */
bool connector_snapshot_active = false;

/* The snapshot.  Read by find_sys_drm_connector_by_busno_or_edid_snapshot()
 * and by nothing else, and written only by the two functions below, which
 * bracket display detection.  Sys_Basic_Drm_Connector rather than
 * Sys_Drm_Connector: what a lookup contributes to a bus record is the
 * connector name and id, matched on bus number or EDID, and the ten further
 * fields of the full record cost sysfs attributes to fill in that nothing here
 * reads.
 */
static GPtrArray * connector_snapshot = NULL;


/** Reads the DRM connectors once, for the lookups display detection is about
 *  to perform.
 *
 *  Called before the per-bus scan rather than after: i2c_check_bus() consults
 *  the connectors while deciding whether to open each device -- see
 *  edid_exists_skips_unmapped_bus in i2c_bus_core.c -- so a snapshot taken
 *  afterwards would be too late to be of use.
 *
 *  Nothing writes the array once it is built, so the per-bus threads that
 *  i2c_async_scan() may start can read it concurrently without a lock.
 */
void take_connector_snapshot() {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "");
   if (connector_snapshot)          // defensive: a detection that did not discard
      free_basic_drm_connectors(connector_snapshot);
   connector_snapshot = scan_basic_drm_connectors(-1);
   connector_snapshot_active = true;
   DBGTRC_DONE(debug, DDCA_TRC_NONE, "%d connectors", connector_snapshot->len);
}


/** Discards the snapshot.
 *
 *  The bus records now carry whatever the connectors had to say, so the array
 *  has served its purpose.  Discarding it is what spares this code a lock, a
 *  refresh and a removal path: what does not outlive detection cannot go stale
 *  and cannot be freed under a caller.
 */
void discard_connector_snapshot() {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "");
   connector_snapshot_active = false;
   free_basic_drm_connectors(connector_snapshot);
   connector_snapshot = NULL;
   DBGTRC_DONE(debug, DDCA_TRC_NONE, "");
}

bool drm_connector_lookup_compare   = false;

// Trace class for this file
// static DDCA_Trace_Group TRACE_GROUP = DDCA_TRC_I2C;


// quick and dirty for debugging
static char *
edid_summary_from_bytes(Byte * edidbytes) {
   static GPrivate  key = G_PRIVATE_INIT(g_free);

   char * buf = get_thread_fixed_buffer(&key, 200);
   if (!edidbytes)
      strcpy(buf, "null edid ptr");
   else {
      Parsed_Edid * parsed = create_parsed_edid(edidbytes);
      if (!parsed)
         strcpy(buf, "Invalid EDID");
      else {
         strcpy(buf, parsed->model_name);
         free_parsed_edid(parsed);
      }
   }

   return buf;
}


/** Determines whether an I2C bus is that of a DisplayLink device,
 *  by examining the bus's sysfs name attribute.
 *
 *  @param  busno  I2C bus number
 *  @return true/false
 */
bool is_displaylink_device(int busno) {
   bool debug = false;
   bool result = false;
   char bus_path[40];
   g_snprintf(bus_path, 40, "/sys/bus/i2c/devices/i2c-%d", busno);
   char * name;
   RPT_ATTR_TEXT((debug)? 1 : -1, &name, bus_path, "name");
   if (name) {
      result =  streq(name, "DisplayLink I2C Adapter");
      free(name);
   }
   return result;
}


/** Determines whether a DRM connector name is that of a laptop display.
 *
 *  @param  connector_name
 *  @return true/false
 */
bool is_laptop_drm_connector_name(const char * connector_name) {
   bool debug = false;
   bool result = strstr(connector_name, "-eDP-") ||
                 strstr(connector_name, "-LVDS-");
   DBGMSF(debug, "connector_name=|%s|, returning %s", connector_name, sbool(result));
   return result;
}


#ifdef UNUSED
#define IS_EDP_DEVICE(_busno) is_laptop_drm_connector(_busno, "-eDP-")
#define IS_LVDS_DEVICE(_busno) is_laptop_drm_connector(_busno, "-LVDS-")


/** Checks whether a /dev/i2c-n device represents an eDP or LVDS device,
 *  i.e. a laptop display.
 *
 *  @param  busno   i2c bus number
 *  #param  drm_name_fragment  string to look for
 *  @return true/false
 *
 *  @remark Works only for DRM displays, therefore use only
 *          informationally.
 */
// Attempting to recode using opendir() and readdir() produced
// a complicated mess.  Using execute_shell_cmd_collect() is simple.
// Simplicity has its virtues.
static bool is_laptop_drm_connector(int busno, char * drm_name_fragment) {
   bool debug = false;
   // DBGTRC_STARTING(debug, DDCA_TRC_NONE, "busno=%d, drm_name_fragment=|%s|", busno, drm_name_fragment);
   bool result = false;

   char cmd[100];
   snprintf(cmd, 100, "ls -d /sys/class/drm/card*/card*/"I2C"-%d", busno);
   // DBGMSG("cmd: %s", cmd);

   GPtrArray * lines = execute_shell_cmd_collect(cmd);
   if (lines)  {    // command should never fail, but just in case
      for (int ndx = 0; ndx < lines->len; ndx++) {
         char * s = g_ptr_array_index(lines, ndx);
         if (strstr(s, drm_name_fragment)) {
            result = true;
            break;
         }
      }
      g_ptr_array_free(lines, true);
   }

   DBGTRC_EXECUTED(debug, TRACE_GROUP, "busno=%d, drm_name_fragment |%s|, Returning: %s",
                              busno, drm_name_fragment, sbool(result));
   return result;
}

#endif




//
// Locating the card-connector directory for an i2c bus
//

/** Emit debug report of a #Found_Sys_Drm_Connector struct
 *
 *  @param val    struct to report
 *  @param depth  logical indentation depth
 */
static void dbgrpt_found_sys_drm_connector(Found_Sys_Drm_Connector val, int depth) {
   rpt_vstring(depth, "Found_Sys_Drm_Connector:");
   rpt_vstring(depth+1, "connector_name:   %s", val.connector_name);
   rpt_vstring(depth+1, "connector_id:     %d", val.connector_id);
   rpt_vstring(depth+1, "found_by:         %s", drm_connector_found_by_name(val.found_by));
}


/** Free the contents of a Found_Sys_Drm_Connector.
 *
 *  Since Found_Sys_Drm_Connector is passed on the stack and never
 *  malloc'd, all that needs to be free's is what the instance points to,
 *  i.e. the connector name.
 *
 *  @param rec Found_Sys_Drm_Connector value, not pointer to the struct
 */
void free_found_sys_drm_connector_result_contents(Found_Sys_Drm_Connector rec) {
   free(rec.connector_name);
}


/** Locates a drm-card-connector directory using either an
 *  I2C bus number or EDID value.
 *
 *  @param  busno      (-1 for not set)
 *  @param  edid_bytes pointer to 128 byte edid
 *  @return Found_Sys_Drm_Connector struct
 *
 *  @remark
 *  Either one of busno or edid_bytes should be set.  Having both parameters
 *  avoids having 2 separate functions, one for bus number and one for EDID,
 *  with essentially the same logic.
 *  @remark
 *  Given its small size, the result is returned on the stack, not
 *  the heap, avoiding the need for the caller to free.
 */
// n. result returned on stack
Found_Sys_Drm_Connector find_sys_drm_connector_by_busno_or_edid_sysfs(
                                 int busno, Byte * edid_bytes)
{
   bool debug  = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, " busno = %d, edid = %p" , busno, edid_bytes);
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "edid=%p -> %s",
         edid_bytes, edid_summary_from_bytes(edid_bytes));
   int d = (IS_DBGTRC(debug, DDCA_TRC_NONE)) ? 1 : -1;
   if (busno == 255)  // happens somehow
      busno = -1;
   bool check_busno = (busno != -1);
   bool check_edid = edid_bytes;
   assert(check_busno || check_edid);

   Found_Sys_Drm_Connector result;
   result.connector_name = NULL;
   result.found_by = DRM_CONNECTOR_NOT_FOUND;
   result.connector_id = 0;

   Sysfs_Connector_Names cnames = get_sysfs_drm_connector_names();
   GPtrArray * drm_connector_names = cnames.all_connectors;
   bool found = false;
   for (int ndx = 0; ndx < drm_connector_names->len && !found; ndx++) {
      char * cname = g_ptr_array_index(drm_connector_names, ndx);
      if (check_busno) {
         Connector_Bus_Numbers * cbn = calloc(1, sizeof(Connector_Bus_Numbers));
         get_connector_bus_numbers("/sys/class/drm", cname, cbn);
         if (cbn->i2c_busno == busno){
            found = true;
            result.connector_name = strdup(cname);
            result.found_by = DRM_CONNECTOR_FOUND_BY_BUSNO;
            result.connector_id = cbn->connector_id;
            DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE,
                  "Found connector %s by i2c bus number match for bus i2c-%d", cname, busno);
         }
         free_connector_bus_numbers(cbn);
      }
      if (check_edid) {
         // don't bother if we already have the answer
         if (result.found_by != DRM_CONNECTOR_FOUND_BY_BUSNO) {
            GByteArray*  edid_bytes_array = NULL;
            POSSIBLY_WRITE_DETECT_TO_STATUS_BY_CONNECTOR_NAME(cname);
            RPT_ATTR_EDID(d, &edid_bytes_array, "/sys/class/drm", cname, "edid");
            if (edid_bytes_array && edid_bytes_array->len >= 128) {
                DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Got edid from sysfs: %s",
                      edid_summary_from_bytes(edid_bytes_array->data));
                if (memcmp(edid_bytes_array->data, edid_bytes, 128) == 0) {
                   found = true;
                   result.connector_name = strdup(cname);
                   result.found_by = DRM_CONNECTOR_FOUND_BY_EDID;
                   // The busno branch above sets connector_id from the Connector_Bus_Numbers
                   // it reads; that read does not happen on this path, so take the attribute
                   // directly.  Without this the field keeps the 0 it was initialized with,
                   // which is invisible wherever the driver publishes the bus/connector
                   // mapping -- there the busno branch succeeds -- and wrong wherever it does
                   // not.  On nvidia every lookup resolves by EDID, so every
                   // businfo->drm_connector_id was 0 and i2c_find_businfo_by_drm_connector_id()
                   // could never match a display.
                   //
                   // Read only on a match, so it costs one attribute per hit rather than one
                   // per connector examined.  Left at 0 if the driver does not publish it.
                   RPT_ATTR_INT(d, &result.connector_id, "/sys/class/drm", cname, "connector_id");
                   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE,
                         "Found connector %s by EDID match for bus i2c-%d, connector_id=%d",
                         cname, busno, result.connector_id);
                }
                g_byte_array_free(edid_bytes_array, true);
            }
         }
      }
   }
   free_sysfs_connector_names_contents(cnames);

   if (IS_DBGTRC(debug, DDCA_TRC_NONE)) {
      dbgrpt_found_sys_drm_connector(result, 1);
   }
   DBGTRC_DONE(debug, DDCA_TRC_NONE, "");
   return result;
}


/** Reports whether any DRM connector names the I2C bus that serves it, i.e.
 *  whether this driver publishes the bus/connector mapping at all.
 *
 *  Walks the connector directories and stops at the first one that names a
 *  bus.  No array is built: the question is a single bit, the answer usually
 *  comes from the first connector examined, and a driver that publishes the
 *  mapping publishes it for every connector, so the loop rarely runs twice.
 *
 *  Reads only the bus/connector artifacts get_connector_bus_numbers() consults
 *  -- the ddc symlink, the i2c-N subdirectory, connector_id -- and not the
 *  EDID or the status, which is what the callers of a full scan pay for and
 *  what this question does not need.
 *
 *  @return true if at least one connector reports a bus number
 */
bool any_drm_connector_has_busno() {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "");

   bool result = false;
   Sysfs_Connector_Names cnames = get_sysfs_drm_connector_names();
   for (int ndx = 0; ndx < cnames.all_connectors->len && !result; ndx++) {
      char * cname = g_ptr_array_index(cnames.all_connectors, ndx);
      Connector_Bus_Numbers * cbn = calloc(1, sizeof(Connector_Bus_Numbers));
      get_connector_bus_numbers("/sys/class/drm", cname, cbn);
      if (cbn->i2c_busno >= 0) {
         result = true;
         DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "%s names bus %d", cname, cbn->i2c_busno);
      }
      free_connector_bus_numbers(cbn);
   }
   free_sysfs_connector_names_contents(cnames);

   DBGTRC_RET_BOOL(debug, DDCA_TRC_NONE, result, "");
   return result;
}


/** Same search as #find_sys_drm_connector_by_busno_or_edid_sysfs(), performed
 *  against the snapshot rather than by walking the connector directories.
 *
 *  Both bus number and EDID come from the same sysfs attributes either way,
 *  read once by take_connector_snapshot() instead of once per call, so the
 *  answers agree.  What is not carried over is the side effect: the walk calls
 *  possibly_write_detect_to_status_by_connector_name() before reading each
 *  edid attribute, forcing the driver to re-probe.  The snapshot makes that
 *  call too, once per connector while it is being built.
 *
 *  @param  busno      (-1 for not set)
 *  @param  edid_bytes pointer to 128 byte edid
 *  @return Found_Sys_Drm_Connector struct, returned on the stack
 */
// n. result returned on stack
Found_Sys_Drm_Connector find_sys_drm_connector_by_busno_or_edid_snapshot(
                                 int busno, Byte * edid_bytes)
{
   bool debug  = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, " busno = %d, edid = %p" , busno, edid_bytes);
   if (busno == 255)  // happens somehow
      busno = -1;
   bool check_busno = (busno != -1);
   bool check_edid = edid_bytes;
   assert(check_busno || check_edid);

   Found_Sys_Drm_Connector result;
   result.connector_name = NULL;
   result.found_by = DRM_CONNECTOR_NOT_FOUND;
   result.connector_id = 0;

   // Bus number first, as the walk does, so that found_by agrees between them.
   Sys_Basic_Drm_Connector * hit = NULL;
   if (check_busno) {
      hit = find_basic_drm_connector_by_busno(connector_snapshot, busno);
      if (hit)
         result.found_by = DRM_CONNECTOR_FOUND_BY_BUSNO;
   }
   if (!hit && check_edid) {
      hit = find_basic_drm_connector_by_edid(connector_snapshot, edid_bytes);
      if (hit)
         result.found_by = DRM_CONNECTOR_FOUND_BY_EDID;
   }
   if (hit) {
      result.connector_name = strdup(hit->connector_name);
      result.connector_id   = hit->connector_id;
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Found connector %s, found_by=%s",
            hit->connector_name, drm_connector_found_by_name(result.found_by));
   }

   if (IS_DBGTRC(debug, DDCA_TRC_NONE)) {
      dbgrpt_found_sys_drm_connector(result, 1);
   }
   DBGTRC_DONE(debug, DDCA_TRC_NONE, "");
   return result;
}


/** Locates a drm-card-connector directory using either an I2C bus number or
 *  EDID value.
 *
 *  The search runs against the persistent #Sys_Drm_Connector array.  Utility
 *  option --f37 selects the original implementation, which walks the connector
 *  directories on every call.  Utility option --f39 runs both and writes a
 *  syslog warning wherever they disagree, which is how the replacement is
 *  meant to be validated on hardware this has not been tried on.  --f37 wins
 *  if both are given, the comparison having nothing to compare against.  See
 *  claude_changes.txt.
 *
 *  @param  busno      (-1 for not set)
 *  @param  edid_bytes pointer to 128 byte edid
 *  @return Found_Sys_Drm_Connector struct, returned on the stack
 */
// n. result returned on stack
Found_Sys_Drm_Connector find_sys_drm_connector_by_busno_or_edid(
                                 int busno, Byte * edid_bytes)
{
   bool use_array = connector_snapshot_active;

   if (!use_array && !drm_connector_lookup_compare)
      return find_sys_drm_connector_by_busno_or_edid_sysfs(busno, edid_bytes);

   // The comparison needs both, and reports whichever the algorithm selected as
   // the answer, so that --f39 does not itself change behavior.
   Found_Sys_Drm_Connector result = (use_array)
         ? find_sys_drm_connector_by_busno_or_edid_snapshot(busno, edid_bytes)
         : find_sys_drm_connector_by_busno_or_edid_sysfs(busno, edid_bytes);
   if (drm_connector_lookup_compare) {    // --f39
      Found_Sys_Drm_Connector alt = (use_array)
            ? find_sys_drm_connector_by_busno_or_edid_sysfs(busno, edid_bytes)
            : find_sys_drm_connector_by_busno_or_edid_snapshot(busno, edid_bytes);
      if (!streq(result.connector_name, alt.connector_name) ||
           result.found_by     != alt.found_by ||
           result.connector_id != alt.connector_id)
      {
         DECORATED_SYSLOG(DDCA_SYSLOG_WARNING,
               "Connector lookup mismatch for busno=%d, edid=%p."
               " Cached: %s, found_by=%s, connector_id=%d."
               " Sysfs: %s, found_by=%s, connector_id=%d.",
               busno, edid_bytes,
               (result.connector_name) ? result.connector_name : "NOT FOUND",
               drm_connector_found_by_name(result.found_by), result.connector_id,
               (alt.connector_name) ? alt.connector_name : "NOT FOUND",
               drm_connector_found_by_name(alt.found_by), alt.connector_id);
      }
      free_found_sys_drm_connector_result_contents(alt);
   }
   return result;
}


/** Returns the value of the edid attribute for a DRM connector.
 *
 *  @param  connector_name
 *  @return pointer to EDID bytes, caller responsible for freeing
 *          NULL if not found
 */
Byte * get_connector_edid(const char * connector_name) {
   bool debug  = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "connector_name = %s", connector_name);
   int d = (debug) ? 1 : -1;

   // char * driver =  get_i2c_sysfs_driver_by_busno(busno);    // where to get busno;
   // maybe_write_detect_to_status("nvidia", connector_name);     // lie

   Byte * result = NULL;
   GByteArray*  edid_bytes = NULL;
   POSSIBLY_WRITE_DETECT_TO_STATUS_BY_CONNECTOR_NAME(connector_name);
   RPT_ATTR_EDID(d, &edid_bytes, "/sys/class/drm", connector_name, "edid");
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "edid_bytes=%p", edid_bytes);
   if (edid_bytes && edid_bytes->len >= 128) {
      DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "edid_bytes->len=%d", edid_bytes->len);
      result = edid_bytes->data;
      g_byte_array_free(edid_bytes, false);
   }
   else {
      if (edid_bytes)   {
         // handle pathological case of < 128 bytes read
         g_byte_array_free(edid_bytes, true);
      }
   }

   DBGTRC_DONE(debug, DDCA_TRC_NONE, "result = %p", result);
   if (IS_DBGTRC(debug, DDCA_TRC_NONE) && result)
      rpt_hex_dump(result, 128, 2);
   return result;
}


 //
 // Functions used only by i2c_check_bus(), but factored out to clarify
 // the function logic
 //

/** Reads the EDID for a bus from the sysfs directory of the DRM connector
 *  recorded in its #I2C_Bus_Info.
 *
 *  @param  businfo  pointer to I2C_Bus_Info instance
 *  @return pointer to parsed EDID, NULL if it could not be read or parsed
 */
Parsed_Edid * get_parsed_edid_for_businfo_using_sysfs(I2C_Bus_Info * businfo) {
    assert(businfo);
    bool debug  = false;
    DBGTRC_STARTING(debug, DDCA_TRC_NONE,
          "businfo = %p, businfo->busno=%d", businfo, businfo->busno);

    Parsed_Edid * pedid = NULL;

    // maybe_write_detect_to_status(businfo->driver, businfo->drm_connector_name);

    Byte * edidbytes = get_connector_edid(businfo->drm_connector_name);
    if (edidbytes) {
       pedid = create_parsed_edid2(edidbytes, "SYSFS");
       if (!pedid) {
          DBGTRC_NOPREFIX(true, DDCA_TRC_NONE, "Invalid EDID read from /sys/class/drm/%s/edid",
                businfo->drm_connector_name);
          DECORATED_SYSLOG(DDCA_SYSLOG_ERROR, "Invalid EDID read from /sys/class/drm/%s/edid",
                businfo->drm_connector_name);
       }
       else {
          DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE,
                "Found edid for /dev/i2c-%d using connector name %s",
                 businfo->busno, businfo->drm_connector_name);
       }
       free(edidbytes);
    }
    else {
       DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE,
             "Failed to get edid using DRM connector %s", businfo->drm_connector_name);
    }

    DBGTRC_DONE(debug, DDCA_TRC_NONE, "Returning %p", pedid);
    return pedid;
 }


/** Determines if a card-connector class attribute represents a
 *  display controller.
 *
 *  @param  adapter_class  class value as string
 *  @return true/false
 */
bool is_adapter_class_display_controller(const char * adapter_class) {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "class = %s", adapter_class);

   bool result = true;
   uint32_t cl2 = 0;
   uint32_t i_class = 0;
   /* bool ok =*/  str_to_int(adapter_class, (int*) &i_class, 16);  // if fails, &result unchanged
   cl2 = i_class & 0xffff0000;
   DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "cl2 = 0x%08x", cl2);
   if (cl2 != 0x030000 && cl2 != 0x0a0000 /* docking station*/ ) {
       DBGTRC_NOPREFIX(debug, DDCA_TRC_NONE, "Device class not a display driver: 0x%08x", cl2);
       result = false;
   }

   DBGTRC_RET_BOOL(debug, DDCA_TRC_NONE, result, "");
   return result;
}


/** Determines whether a DRM connector name is that of an existing
 *  card-connector directory in /sys/class/drm.
 *
 *  @param  connector_name
 *  @return true/false
 */
bool is_valid_drm_connector_name(const char * connector_name) {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "connector_name=|%s|", connector_name);

   char * fq_name = g_strdup_printf("/sys/class/drm/%s", connector_name);
   bool result = directory_exists(fq_name);

   DBGTRC_DONE(debug, DDCA_TRC_NONE, "Connector_name=|%s|, fq_name=|%s|, returning %s",
         connector_name, fq_name, sbool(result));
   free(fq_name);
   return result;
}


#ifdef UNUSED
 // TODO: MOVE ELSEWHERE
 /** Scans a single connector directory of /sys/class/drm.
  *
  *  Has typedef Dir_Foreach_Func
  *
  *  Adds the card-connector (as a string) to a #GPtrArray.
  *
  *  @param   dirname
  *  @param   fn
  *  @param   accumulator  #GPtrArray to collect the names
  *  @param   depth        ignored
  */
 void add_one_drm_connector_name(
       const char *  dirname,      // /sys/class/drm
       const char *  fn,           // e.g. card0-DP-1
       void *        accumulator,
       int           depth)
 {
    bool debug = false;
    DBGTRC_STARTING(debug, TRACE_GROUP, "dirname=%s, fn=%s, depth=%d", dirname, fn, depth);

    GPtrArray * connectors = accumulator;
    g_ptr_array_add(connectors, g_strdup(fn));

    DBGTRC_DONE(debug, TRACE_GROUP, "");
 }


 /** Returns a GPtrArray of all the card-connector directory names,
  *  e.g. card1-HDMI-A-1
  *
  *  @return #GPtrArray of names, caller must free
  */
 GPtrArray *  get_drm_connector_names() {
    bool debug = false;
    DBGTRC_STARTING(debug, DDCA_TRC_I2C,"");

    GPtrArray * connector_names = g_ptr_array_new_with_free_func(free_sys_drm_connector);
    dir_filtered_ordered_foreach(
          "/sys/class/drm",
          is_drm_connector,      // filter function
          NULL,                  // ordering function
          add_one_drm_connector_name,
          connector_names,    // accumulator, GPtrArray *
          -1);
    DBGTRC_DONE(debug, DDCA_TRC_I2C, "size of sys_drm_connectors: %d", sys_drm_connectors->len);
    return connector_names;
 }


 /** Do card-connector directories exist?
  *
  *  @return true/false
  */
 bool drm_connectors_exist() {
    bool debug = false;
    DBGTRC_STARTING(debug, DDCA_TRC_I2C, "");
    GPtrArray * connector_names = get_drm_connector_names();
    bool result = (connector_names->len > 0);
    g_ptr_array_free(connector_names, true);
    DBGTRC_RET_BOOL(debug, DDCA_TRC_I2C, result, "");
    return result;
 }
#endif

 
//
// I2C bus / DRM connector associations supplied by the user,
// i.e. option --bus-drm-connector
//

 static GPtrArray * user_busno_connector_table;

 typedef struct {
    int    busno;
    char * drm_connector_name;
 } Busno_Connector_Table_Entry;


 static void free_busno_connector_table_entry (void * ptr) {
    Busno_Connector_Table_Entry * entry = (Busno_Connector_Table_Entry *) ptr;
    if (entry) {
       free(entry->drm_connector_name);  // ok if null
    }
    free(entry);
 }


/** Returns the I2C bus number that the user has associated with a DRM connector
 *  name, using option --bus-drm-connector.
 *
 *  The reverse of #user_drm_connector_for_busno().
 *
 *  @param  drm_connector_name  connector name, e.g. "card1-DP-2"
 *  @return I2C bus number, -1 if the connector is not in the table
 */
int user_busno_for_drm_connector(const char * drm_connector_name) {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "drm_connector_name=%s, user_busno_connector_table=%p",
                                         drm_connector_name, user_busno_connector_table);

   int result = -1;
   if (drm_connector_name && user_busno_connector_table) {
      for (int ndx = 0; ndx < user_busno_connector_table->len; ndx++) {
         Busno_Connector_Table_Entry * entry = g_ptr_array_index(user_busno_connector_table, ndx);
         if (streq(entry->drm_connector_name, drm_connector_name)) {
            result = entry->busno;
            break;
         }
      }
   }

   DBGTRC_RET_DDCRC(debug, DDCA_TRC_NONE, result, "");
   return result;
}


/** Returns the DRM connector name that the user has associated with an I2C bus
 *  number, using option --bus-drm-connector.
 *
 *  @param  busno  I2C bus number
 *  @return connector name, NULL if the bus number is not in the table
 *
 *  @remark
 *  The returned value belongs to the table.  Do not free.
 */
const char * user_drm_connector_for_busno(int busno) {
   bool debug = false;
   DBGTRC_STARTING(debug, DDCA_TRC_NONE, "busno=%d, user_busno_connector_table=%p",
                                         busno, user_busno_connector_table);

   const char * result = NULL;
   if (user_busno_connector_table) {
      for (int ndx = 0; ndx < user_busno_connector_table->len; ndx++) {
         Busno_Connector_Table_Entry * entry = g_ptr_array_index(user_busno_connector_table, ndx);
         if (entry->busno == busno) {
            result = entry->drm_connector_name;
            break;
         }
      }
   }

   DBGTRC_RET_STRING(debug, DDCA_TRC_NONE, result, "");
   return result;
}


void add_busno_connector(int busno, const char * connector_name) {
   Busno_Connector_Table_Entry* entry = calloc(1, sizeof(Busno_Connector_Table_Entry));
   entry->busno = busno;
   entry->drm_connector_name = strdup(connector_name);
   if (!user_busno_connector_table)
      user_busno_connector_table = g_ptr_array_new_full(4, free_busno_connector_table_entry);
   g_ptr_array_add(user_busno_connector_table, entry);
}


void dbgrpt_busno_connector_table(int depth) {
   rpt_label(depth, "busno_connector_table contents:");
   if (user_busno_connector_table) {
      for (int ndx = 0; ndx < user_busno_connector_table->len; ndx++) {
         Busno_Connector_Table_Entry * entry = g_ptr_array_index(user_busno_connector_table, ndx);
         rpt_vstring(depth+1, "/dev/i2c-%d  -  %s",  entry->busno, entry->drm_connector_name);
      }
   }
   else
      rpt_label(depth+1, "Empty");
}


/** Module initialization */
void init_i2c_bus_sysfs() {
   RTTI_ADD_FUNC(find_sys_drm_connector_by_busno_or_edid);
   RTTI_ADD_FUNC(find_sys_drm_connector_by_busno_or_edid_sysfs);
   RTTI_ADD_FUNC(find_sys_drm_connector_by_busno_or_edid_snapshot);
   RTTI_ADD_FUNC(any_drm_connector_has_busno);
   RTTI_ADD_FUNC(get_connector_edid);
   RTTI_ADD_FUNC(get_parsed_edid_for_businfo_using_sysfs);
   RTTI_ADD_FUNC(is_adapter_class_display_controller);
   RTTI_ADD_FUNC(is_valid_drm_connector_name);
   RTTI_ADD_FUNC(user_drm_connector_for_busno);
   RTTI_ADD_FUNC(user_busno_for_drm_connector);
}
