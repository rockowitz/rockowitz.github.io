/** @file regex_util.c */

// Copyright (C) 2021-2026 Sanford Rockowitz <rockowitz@minsoft.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#include <assert.h>
#include <glib-2.0/glib.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "debug_util.h"
#include "report_util.h"
#include "regex_util.h"
#include "string_util.h"
#include "sysfs_util.h"
 

//
// Store compiled regular expressions
//

static GHashTable * regex_hash_table = NULL;
static GMutex       regex_hash_table_mutex;


// GDestroyNotify void (*GDestroyNotify) (gpointer data);
void destroy_regex(gpointer data) {
   // printf("(%s) Destroying compiled regex at %p\n", __func__, data);
   regfree( (regex_t*) data );
   free(data);                      // ???
}


GHashTable* get_regex_hash_table() {
   // printf("(%s) Starting. regex_hash_table = %p\n", __func__, regex_hash_table);
   if (!regex_hash_table)
      regex_hash_table = g_hash_table_new_full(
            g_str_hash,                // GHashFunc hash_func,
            g_str_equal,               // GEqualFunc key_equal_func,
            g_free,                    // GDestroyNotify key_destroy_func,
            destroy_regex);            // GDestroyNotify value_destroy_func

   // printf("(%s) Done. Returning regex_hash_table = %p\n", __func__, regex_hash_table);
   return regex_hash_table;
}


void dbgrpt_regex_hash_table() {
   if (regex_hash_table) {
      GHashTableIter iter;
      gpointer key, value;
      g_hash_table_iter_init(&iter, regex_hash_table);
      while (g_hash_table_iter_next(&iter, &key, &value)) {
          rpt_vstring(2, "   %p->\"%s\"  :   %p", key, (char *) key, value);
      }
   }
   else
      rpt_vstring(1, "regex_hash_table not allocated");
}


void free_regex_hash_table() {
   bool debug = false;
   DBGF(debug, "Starting. regex_hash_table=%p", (void*)regex_hash_table);
   g_mutex_lock(&regex_hash_table_mutex);
   if (regex_hash_table) {
      if (debug) {
         DBG("Hash table contents:");
         dbgrpt_regex_hash_table();
      }
      g_hash_table_destroy(regex_hash_table);
      regex_hash_table = NULL;
   }
   g_mutex_unlock(&regex_hash_table_mutex);
   DBGF(debug, "Done.");
}


static void save_compiled_regex(const char * pattern, regex_t * compiled_re) {
   bool debug = false;
   DBGF(debug, "Starting. pattern = |%s|, compiled_re=%p", pattern, (void*)compiled_re);
   GHashTable * regex_hash = get_regex_hash_table();
   g_hash_table_replace(regex_hash, g_strdup( pattern), compiled_re);
   DBGF(debug, "Done.");
}


static regex_t * get_compiled_regex(const char * pattern) {
   bool debug = false;
   DBGF(debug, "Starting. pattern = |%s|", pattern);
   GHashTable * regex_hash = get_regex_hash_table();
   regex_t * result = g_hash_table_lookup(regex_hash, pattern);
   DBGF(debug, "Returning %p. pattern = |%s|", (void*)result, pattern);
   return result;
}

// #ifdef FUTURE
// requires testing
bool eval_regex_with_matches(
      regex_t *     re,
      const char *  value,
      size_t        max_matches,
      regmatch_t *  pm )
{
   bool debug = false;
   DBGF(debug, "Starting. re=%p, value=|%s|", (void*)re, value);
   int rc = regexec(
          re,                   /* the compiled pattern */
          value,                /* the subject string */
          max_matches,
          pm,
          0
       );
   bool result = (rc  == 0) ? true : false;
   DBGF(debug, "Returning %s. value=|%s|, regexec() returned %d",
               sbool(result), value, rc);
   return result;
}
// #endif


static bool eval_regex(regex_t * re, const char * value) {
   bool debug = false;
   DBGF(debug, "Starting. re=%p, value=|%s|", (void*)re, value);
   int rc = regexec(
          re,                   /* the compiled pattern */
          value,                /* the subject string */
          0,
          NULL,
          0
       );
   bool result = (rc  == 0) ? true : false;
   DBGF(debug, "Returning %s. value=|%s|, regexec() returned %d",
               sbool(result), value, rc);
   return result;
}


/** Returns the compiled regex for a pattern, compiling and caching it on
 *  first use.
 *
 *  Only the hash table lookup and insertion run under
 *  regex_hash_table_mutex.  The returned regex may safely be used after
 *  the mutex is released: regexec() on a compiled regex is thread-safe,
 *  and a cached regex is never freed while the program runs, since a
 *  pattern is compiled at most once (the lookup and insertion are atomic
 *  with respect to each other, so g_hash_table_replace() never destroys
 *  an entry that is in use).
 */
static regex_t * get_or_compile_regex(const char * pattern) {
   bool debug = false;
   g_mutex_lock(&regex_hash_table_mutex);
   regex_t * re = get_compiled_regex(pattern);
   // printf("(%s) forcing re = NULL\n", __func__);
   // re = NULL;
   if (!re) {
      re = calloc(1, sizeof(regex_t));
      DBGF(debug, "Allocated regex %p, compiling...", (void*)re);
      int rc = regcomp(re, pattern, REG_EXTENDED);
      if (rc != 0) {
         printf("(%s) regcomp() returned %d\n", __func__, rc);
         assert(rc == 0);
      }
      save_compiled_regex(pattern, re);
   }
   g_mutex_unlock(&regex_hash_table_mutex);
   return re;
}


bool compile_and_eval_regex(const char * pattern, const char * value) {
   bool debug = false;
   DBGF(debug, "Starting. pattern=|%s|, value=|%s|", pattern, value);
   regex_t * re = get_or_compile_regex(pattern);
   // Evaluation runs outside the mutex; holding it here serialized all
   // regex evaluation across threads.
   bool result = eval_regex(re, value);
   DBGF(debug, "Done. Returning %s", sbool(result));
   return result;
}


bool compile_and_eval_regex_with_matches(
      const char * pattern,
      const char * value,
      size_t       max_matches,
      regmatch_t * pm)
{
   bool debug = false;
   DBGF(debug, "Starting. pattern=|%s|, value=|%s|", pattern, value);
   regex_t * re = get_or_compile_regex(pattern);
   // Evaluation runs outside the mutex; holding it here serialized all
   // regex evaluation across threads.
   bool result = eval_regex_with_matches(re, value, max_matches, pm);
   DBGF(debug, "Done. Returning %s", sbool(result));
   return result;
}
